<?php
/**
 * Flatsome functions and definitions
 *
 * @package flatsome
 */

require get_template_directory() . '/inc/init.php';

/**
 * Note: It's not recommended to add any custom code here. Please use a child theme so that your customizations aren't lost during updates.
 * Learn more here: http://codex.wordpress.org/Child_Themes
 */

//remove featured_item
function apw_remove_custom_post_type_slug($post_link, $post, $leavename)
{

    if (!in_array($post->post_type, array('featured_item')) || 'publish' != $post->post_status)
        return $post_link;

    $post_link = str_replace('/' . $post->post_type . '/', '/', $post_link);

    return $post_link;
}

add_filter('post_type_link', 'apw_remove_custom_post_type_slug', 10, 3);

function apw_parse_request_tricksy($query)
{

    if (!$query->is_main_query())
        return;

    if (2 != count($query->query)
        || !isset($query->query['page']))
        return;

    if (!empty($query->query['name']))
        $query->set('post_type', array('post', 'featured_item', 'page'));
}

add_action('pre_get_posts', 'apw_parse_request_tricksy');

//remove featured_item_category
add_filter('request', 'apw_change_term_request', 1, 1);

function apw_change_term_request($query)
{

    $tax_name = 'featured_item_category'; // specify you taxonomy name here, it can be also 'category' or 'post_tag'

    // Request for child terms differs, we should make an additional check
    if ($query['attachment']) :
        $include_children = true;
        $name = $query['attachment'];
    else:
        $include_children = false;
        $name = $query['name'];
    endif;


    $term = get_term_by('slug', $name, $tax_name); // get the current term to make sure it exists

    if (isset($name) && $term && !is_wp_error($term)): // check it here

        if ($include_children) {
            unset($query['attachment']);
            $parent = $term->parent;
            while ($parent) {
                $parent_term = get_term($parent, $tax_name);
                $name = $parent_term->slug . '/' . $name;
                $parent = $parent_term->parent;
            }
        } else {
            unset($query['name']);
        }

        switch ($tax_name):
            case 'category':
            {
                $query['category_name'] = $name; // for categories
                break;
            }
            case 'post_tag':
            {
                $query['tag'] = $name; // for post tags
                break;
            }
            default:
            {
                $query[$tax_name] = $name; // for another taxonomies
                break;
            }
        endswitch;

    endif;

    return $query;

}


add_filter('term_link', 'apw_term_permalink', 10, 3);

function apw_term_permalink($url, $term, $taxonomy)
{

    $taxonomy_name = 'featured_item_category'; // your taxonomy name here
    $taxonomy_slug = 'featured_item_category'; // the taxonomy slug can be different with the taxonomy name (like 'post_tag' and 'tag' )

    // exit the function if taxonomy slug is not in URL
    if (strpos($url, $taxonomy_slug) === FALSE || $taxonomy != $taxonomy_name) return $url;

    $url = str_replace('/' . $taxonomy_slug, '', $url);

    return $url;
}