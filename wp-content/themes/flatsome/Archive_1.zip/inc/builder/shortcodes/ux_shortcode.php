<?php

add_ux_builder_shortcode( 'ux_shortcode', array(
  'name' => 'Shortcode',
  'category' => __( 'Content' ),
  'thumbnail' =>  flatsome_ux_builder_thumbnail( 'ux_hotspot' ),
  'options'=> array(
    )
) );